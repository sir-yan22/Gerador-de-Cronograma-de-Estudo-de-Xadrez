
export const topicToBibKey: { [key: string]: string } = {
    "Geral": "Geral",
    "Tática": "Tática",
    "Cálculo": "Cálculo",
    "Partidas Completas": "Partidas",
    "Partidas": "Partidas",
    "Finais": "Finais",
    "Aberturas": "Aberturas",
    "Estratégia": "Estratégia",
    "Cursos Online": "Cursos Online"
};
